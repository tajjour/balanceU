package com.harvard.group3.cucumber;

import cucumber.api.PendingException;
import cucumber.api.java.en.*;

/**
 * Created by tajjour on 2016-11-13.
 */
public class BalanceUDefinitions {
    @Given("^first POC$")
    public void first_POC() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }

    @When("^Second POC$")
    public void second_POC() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }

    @Then("^Third POC$")
    public void third_POC() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }
}
